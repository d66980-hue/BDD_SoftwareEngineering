package com.hotel.api.controller;

import com.hotel.api.model.User;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/users")
public class UserController {

    private Map<Long, User> users = new HashMap<>();
    private Long idCounter = 1L;

    // CREATE USER
    @PostMapping
    public User createUser(@RequestBody User user) {
        user.setId(idCounter++);
        users.put(user.getId(), user);
        return user;
    }

    // GET ALL USERS
    @GetMapping
    public Collection<User> getAllUsers() {
        return users.values();
    }

    // GET USER BY ID
    @GetMapping("/{id}")
    public User getUser(@PathVariable Long id) {
        return users.get(id);
    }

    // UPDATE USER
    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User updatedUser) {
        User user = users.get(id);
        if (user != null) {
            user.setName(updatedUser.getName());
            user.setUsername(updatedUser.getUsername());
            user.setEmail(updatedUser.getEmail());
            user.setRole(updatedUser.getRole());
        }
        return user;
    }

    // DELETE USER
    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable Long id) {
        users.remove(id);
        return "User removed successfully";
    }
}